package com.TodoList;
	import java.util.ArrayList;
	import java.util.Scanner;

	class TodoList {
	    String description;
	    boolean isCompleted;

	    TodoList(String description) {
	        this.description = description;
	        this.isCompleted = false;
	    }

	    void markAsCompleted() {
	        isCompleted = true;
	    }

	    @Override
	    public String toString() {
	        return (isCompleted ? "[✔] " : "[ ] ") + description;
	    }
	}

	public class ToDoList {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        ArrayList<ToDoList> tasks = new ArrayList<>();

	        System.out.println("Welcome to your To-Do List Manager! ✅\n");

	        while (true) {
	            System.out.println("What would you like to do?");
	            System.out.println("1. Add a new task");
	            System.out.println("2. View all tasks");
	            System.out.println("3. Mark a task as complete");
	            System.out.println("4. Delete a task");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice (1-5): ");

	            int choice = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter task description: ");
	                    String description = scanner.nextLine();
	                    tasks.add(new ToDoList());
	                    System.out.println("Task added successfully! 📝\n");
	                    break;
	                case 2:
	                    if (tasks.isEmpty()) {
	                        System.out.println("No tasks available. Start adding some! 📋\n");
	                    } else {
	                        System.out.println("Your Tasks:");
	                        for (int i = 0; i < tasks.size(); i++) {
	                            System.out.println((i + 1) + ". " + tasks.get(i));
	                        }
	                        System.out.println();
	                    }
	                    break;
	                case 3:
	                    System.out.print("Enter the task number to mark as complete: ");
	                    int completeIndex = scanner.nextInt() - 1;
	                    if (completeIndex >= 0 && completeIndex < tasks.size()) {
	                        tasks.get(completeIndex).markAsCompleted();
	                        System.out.println("Task marked as completed! ✅\n");
	                    } else {
	                        System.out.println("Invalid task number. Try again! ❌\n");
	                    }
	                    break;
	                case 4:
	                    System.out.print("Enter the task number to delete: ");
	                    int deleteIndex = scanner.nextInt() - 1;
	                    if (deleteIndex >= 0 && deleteIndex < tasks.size()) {
	                        tasks.remove(deleteIndex);
	                        System.out.println("Task deleted successfully! 🗑️\n");
	                    } else {
	                        System.out.println("Invalid task number. Try again! ❌\n");
	                    }
	                    break;
	                case 5:
	                    System.out.println("Goodbye! Have a productive day! 🚀");
	                    scanner.close();
	                    return;
	                default:
	                    System.out.println("Oops! That’s not a valid choice. Try again. ⚠️\n");
	            }
	        }
	    }

		private void markAsCompleted() {
			// TODO Auto-generated method stub
			
		}
	}

