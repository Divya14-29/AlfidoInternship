package NumberGuessGame.com;

	import java.util.Random;
	import java.util.Scanner;
 public class Game {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        Random random = new Random();
	        int targetNumber = random.nextInt(100) + 1; // Random number between 1 and 100
	        int attempts = 0;
	        int guess = 0;
	        
	        System.out.println("Welcome to the Number Guessing Game! 🎉");
	        System.out.println("I've picked a number between 1 and 100. Can you guess it?");
	        
	        while (guess != targetNumber) {
	            System.out.print("Enter your guess: ");
	            try {
	                guess = scanner.nextInt();
	                attempts++;
	                
	                if (guess < 1 || guess > 100) {
	                    System.out.println("Oops! Your guess should be between 1 and 100. Try again! ⚠️");
	                } else if (guess < targetNumber) {
	                    System.out.println("Too low! Try a bigger number. ⬆️");
	                } else if (guess > targetNumber) {
	                    System.out.println("Too high! Try a smaller number. ⬇️");
	                } else {
	                    System.out.println("Congratulations! 🎉 You guessed the number in " + attempts + " attempts!");
	                }
	            } catch (Exception e) {
	                System.out.println("Oops! That doesn't look like a valid number. Please enter a number between 1 and 100. ⚠️");
	                scanner.next(); // Clear invalid input
	            }
	        }
	        
	        scanner.close();
	    }
	}


}
